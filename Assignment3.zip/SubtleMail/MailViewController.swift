//
//  MailViewController.swift
//  SubtleMail
//
//  Created by Alexander on 10/29/16.
//  Copyright © 2016 Alexander. All rights reserved.
//

import UIKit

class MailViewController: UIViewController,UIScrollViewDelegate, UIGestureRecognizerDelegate {

    @IBOutlet weak var scrollView: UIScrollView!
    @IBOutlet weak var feedImage: UIImageView!
    @IBOutlet weak var viewMessage: UIView!
    
    @IBOutlet weak var viewLeft: UIView!
    @IBOutlet weak var viewRight: UIView!
    
    //Icons
    @IBOutlet weak var clockView: UIImageView!
    @IBOutlet weak var listView: UIImageView!

    var viewMessageOriginalCenter: CGPoint!
    var viewMessageLeft: CGPoint!
    var viewMessageRight: CGPoint!
    var clockViewOriginalCenter: CGPoint!
    
     var clockOn = 1
    
    //view reference
    var rescheduleView:UIImageView!
    var fullListView:UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        scrollView.delegate = self
        scrollView.contentSize = feedImage.frame.size
        viewMessageOriginalCenter = viewMessage.center
        clockView.alpha = 0
        clockViewOriginalCenter = clockView.center
        listView.alpha = 0
        //checkMark.alpha = 0
        //XMark.alpha = 0 
        
        
        addView() // Add message view screen
        rescheduleView.alpha = 0
        addFullListView()
        fullListView.alpha = 0
        
     //   clockView.center.x = clockView.center.x + 145
        
       
       
        
        print("The Original View Message Center is \(viewMessageOriginalCenter)")
        // Add Pan Gesture to View Message
        let pan = UIPanGestureRecognizer(target: self, action: #selector(didPan(sender:)))
        pan.delegate = self
        viewMessage.addGestureRecognizer(pan)
        viewMessage.isUserInteractionEnabled = true
        
        // Add Edge Pan
        let edgePan = UIScreenEdgePanGestureRecognizer(target: self, action: #selector(handleEdgePan(sender:)))
        edgePan.delegate = self
        edgePan.edges = UIRectEdge.left
        self.view.addGestureRecognizer(edgePan)
        self.view.isUserInteractionEnabled  = true
        self.view.addGestureRecognizer(edgePan)
    }
    
        
//        let frame = CGRect(x: 0, y: 0, width: 320, height: 568)
//        let imageView = UIImageView(frame: frame)
//        imageView.backgroundColor = UIColor.blue
//        imageView.alpha = 1
//        imageView.image = UIImage(named: "reschedule")
//        imageView.isUserInteractionEnabled = true
//        view.insertSubview(imageView, at: 14)
        
        // Add Gradient color ---------------------
//        let gradientLayer = CAGradientLayer()
//        let color1 = UIColor(white:0.91, alpha:1.0).cgColor
//        let color2 = UIColor(white:0.91, alpha:1.0).cgColor
//        let color3 = UIColor(white:0.91, alpha:1.0).cgColor
//        gradientLayer.frame = CGRect(x: 0, y: 0, width: 320, height: 86)
//        gradientLayer.colors = [color1, color2, color3]
//        // Set the color stops
//        gradientLayer.locations = [1, 1, 1]
//        //var frame = CGRect(x: 0, y: -136, width: 320, height: 86)
//        viewLeft.layer.addSublayer(gradientLayer)
        

        
        
//        // Create gradient layer
//        let gradientLayer = CAGradientLayer()
//        // Create your colors as CGColor
//        let color1 = UIColor.darkGray.cgColor
//        let color2 = UIColor.gray.cgColor
//        let color3 = UIColor.lightGray.cgColor
//        // Set gradient layer frame
//        gradientLayer.frame = self.view.frame
//        
//        // Add colors to gradient layer
//        gradientLayer.colors = [color1, color2, color3]
//        
//        // Set the color stops
//        gradientLayer.locations = [0, 0.5, 1]
//        
//        // Add gradient layer to view layer
//

        // Do any additional setup after loading the view.
    

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func scrollViewDidScroll(_ scrollView: UIScrollView) {
        // This method is called as the user scrolls
    }
    
   
    
    func didPan(sender: UIPanGestureRecognizer) {
        print("Pan Message View")
        let location = sender.location(in: view)
        let velocity = sender.velocity(in: view)
        let translation = sender.translation(in: view)
        print("The value of translation is ::: \(translation)")
        
        // Reveal Multicolor Backgrounds on Swipe
        switch sender.state {
        case .began:
            print("Pan has begun my friends")
//            if velocity.x <= 0 {
//                UIView.animate(withDuration:3.0, animations: {
//                    self.clockView.alpha = 1
//                })
//                
//            }
           

        case .changed:
            print("Pan is changing.")
            self.viewMessage.center = CGPoint(x: self.viewMessageOriginalCenter.x + translation.x, y: self.viewMessageOriginalCenter.y)
            
            switch translation.x {
                
            // --far left-- // // Brown
            case (-1000)...(-160):
                //List
               self.viewLeft.backgroundColor = UIColor(red:0.86, green:0.7, blue:0.51, alpha:1.0)
               UIView.animate(withDuration:0.3, animations: {
                self.clockView.alpha = 0
               })
               UIView.animate(withDuration:0.3, animations: {
                self.listView.alpha = 1
               })
                
                showListView()
                
            // --mid left-- // // Yellow
            case (-159)...(-60):
                //Yellow - Schedule
                // Check for user HOVER
                // Add reschedule view
                UIView.animate(withDuration:0.2, animations: {
                    self.clockView.alpha = 1
                })
                print("Translation x: \(translation.x)")
                 self.clockView.center = CGPoint(x: self.clockViewOriginalCenter.x+30+(translation.x)/1, y: self.clockView.center.y)
                
                self.viewLeft.backgroundColor = UIColor(red:0.98, green:0.85, blue:0.22, alpha:1.0)
                print("The TRANSLATION OF X IS = \(translation.x)")
                if velocity.x >= (-10) && velocity.x <= 10 {
                    print("The value of velocity is ::: \(velocity.x)")
                    print("USER IS HOVERING - HOVER STATE ACHIEVED")
                    //ACTIVATE SCHEDULE SCREEN
                    show()
                } //velocity sender
                
                
            // -- left -- // //Gray
            case (-59)...(-1):
                
                UIView.animate(withDuration:0.9, animations: {
                                             //   self.listView.alpha = 1
                                                self.clockView.alpha = 1
                                              //  self.clockOn = 0
                                            })
                  self.clockView.center = CGPoint(x: self.clockViewOriginalCenter.x-20, y: self.clockView.center.y)
                
                
                // Fade in Clock Icon
              //  toggleLeftIcons(){
                    
                
//                    if (clockOn == 1) {
//                        
//                        UIView.animate(withDuration:3.0, animations: {
//                            self.listView.alpha = 1
//                            self.clockView.alpha = 0
//                            self.clockOn = 0
//                        })
//                        
//                    } else if (clockOn == 0) {
//                        UIView.animate(withDuration:3.0, animations: {
//                            self.clockView.alpha = 1
//                            self.listView.alpha = 0
//                            self.clockOn = 1
//                        })
//                    }
                
               // }  // toggleLeft
                
                // Add Gray Color
                self.viewLeft.backgroundColor = UIColor(white:0.91, alpha:1.0)
            
            // -- right --//
            case 0...60:
                self.viewLeft.backgroundColor = UIColor(white:0.91, alpha:1.0)
               

            
            // -- mid right -- //
            case 61...160:
               self.viewLeft.backgroundColor = UIColor(red:0.51, green:0.87, blue:0.43, alpha:1.0)
            
            // -- far right -- //
            case 160...1000:
              UIView.animate(withDuration: 0.3, animations: {
                self.viewLeft.backgroundColor = UIColor(red:0.51, green:0.87, blue:0.43, alpha:1.0)
                self.viewLeft.backgroundColor = UIColor(red:0.91, green:0.4, blue:0.23, alpha:1.0)
              })
                // -- default -- //
            default:
                print("do nothing")
            }
            
        case .ended:
            print("Pan ended")
            // Would make sense to check velocity here, if paused, then show screen, if  just dropped, then bounces back, this way the user doesn't wait on the interface
            UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 10, options: [], animations: {
                self.viewMessage.center = self.viewMessageOriginalCenter
                }, completion: nil)
            
        default:
            print("default case")
        }
        
        
        
        
//        if sender.state == .began{
//            
//        } else if sender.state == .changed{
//             self.viewMessage.center = CGPoint(x: self.viewMessageOriginalCenter.x + translation.x, y: self.viewMessageOriginalCenter.y)
//            
//        } else if sender.state == .ended{
//            UIView.animate(withDuration: 0.6, delay: 0, usingSpringWithDamping: 0.5, initialSpringVelocity: 10, options: [], animations: {
//                 self.viewMessage.center = self.viewMessageOriginalCenter
//                }, completion: nil)
//            
            // As my velocity increases, my spring withDuration goes down, as I'm in hurry my UI speeds up also.

           // }
        
        
        print("Pan Velocity is = \(velocity)")
        
//        if velocity.x > 0 {
//            print("Swiped Right")
//            self.viewRight.alpha = self.viewRight.alpha-0.01
//
//            self.viewLeft.alpha = self.viewLeft.alpha+0.01
//        } else if velocity.x < 0 {
//            print("Swipe Left")
//            self.viewLeft.alpha = self.viewLeft.alpha-0.01
//            self.viewRight.alpha = self.viewRight.alpha+0.01
//        }
        
    
        
    // FUNCTION DECLARATIONS
       
    }
    
    func didTap(sender: UITapGestureRecognizer){
        print("Did tap")
        
        //toggle()
        
        
        if self.rescheduleView.alpha == 1 {
            self.hide()
        } else if self.rescheduleView.alpha == 0 {
            self.hideListView()
        }
        
//       imageView.sendSubview(toBack)
//        for imageView in self.view.subviews {
//            imageView.removeFromSuperview()
//        }
        
    }
    func handleEdgePan(sender: UIPanGestureRecognizer) {
        
        print("GETTING SCREEEN EDGY)")
    }


    func userSwipedFromEdge(sender: UIScreenEdgePanGestureRecognizer) {
        if sender.edges == UIRectEdge.left {
            print("It works!")
        }
    }
    
    //MARK - View Functions
    
    func addView() {
        rescheduleView = UIImageView(image: UIImage(named: "reschedule"))
        rescheduleView.frame = self.view.bounds
        
        //CGRect(x: 0, y: 0, width: 320, height: 568)
        
        //setup view
        rescheduleView.backgroundColor = UIColor.blue
        rescheduleView.isUserInteractionEnabled = true
        
        //ADD subview
        view.addSubview(rescheduleView)
        
        let tapSchedule = UITapGestureRecognizer(target: self, action: #selector(didTap(sender:)))
        tapSchedule.delegate = self
        rescheduleView.addGestureRecognizer(tapSchedule)
        rescheduleView.isUserInteractionEnabled = true
    }
    
    func addFullListView() {
        fullListView = UIImageView(image: UIImage(named: "list"))
        fullListView.frame = self.view.bounds
        
        //CGRect(x: 0, y: 0, width: 320, height: 568)
        
        //setup view
        fullListView.backgroundColor = UIColor.blue
        fullListView.isUserInteractionEnabled = true
        
        //ADD subview
        view.addSubview(fullListView)
        
        let tapSchedule = UITapGestureRecognizer(target: self, action: #selector(didTap(sender:)))
        tapSchedule.delegate = self
        fullListView.addGestureRecognizer(tapSchedule)
        fullListView.isUserInteractionEnabled = true
    }

    
    func toggle() {
        if self.rescheduleView.isHidden {
            self.show()
        } else {
            self.hide()
        }
    }
    
    func hide() {
        UIView.animate(withDuration: 1.5, animations: {
            self.rescheduleView.alpha = 0
            }, completion: { (done) in
                //just delete
                self.rescheduleView.isHidden = true
        })
    }
    
    func show() {
        self.rescheduleView.isHidden = false
        UIView.animate(withDuration: 1.5, animations: {
            self.rescheduleView.alpha = 1
            }, completion: nil)
    }
    
    
    // Add fullListView
    func toggleListView() {
        if self.fullListView.isHidden {
            self.showListView()
        } else {
            self.hideListView()
        }
    }
    
    func hideListView() {
        UIView.animate(withDuration: 1.5, animations: {
            self.fullListView.alpha = 0
            }, completion: { (done) in
                //just delete
                self.fullListView.isHidden = true
        })
    }
    
    func showListView() {
        self.fullListView.isHidden = false
        UIView.animate(withDuration: 1.5, animations: {
            self.fullListView.alpha = 1
            }, completion: nil)
    }
    
    // Convert Function
    func convertValue(inputValue: CGFloat, r1Min: CGFloat, r1Max: CGFloat, r2Min: CGFloat, r2Max: CGFloat) -> CGFloat {
        let ratio = (r2Max - r2Min) / (r1Max - r1Min)
        return inputValue * ratio + r2Min - r1Min * ratio
    }
    
} // END class
